import java.util.ArrayList;
import java.util.Scanner;
import java.lang.Math;
public class Main {

  public static void main(String[] args) {

    Scanner Scanner = new Scanner(System.in);
    boolean loop = false;
    while (loop == false) {

      System.out.println("Enter a binary number to convert to decimal.");

      ArrayList < Integer > numbers = new ArrayList < Integer > ();

      int sum = 0;
      Integer binary = 0;
      String binaryString = "";

      binary = Scanner.nextInt();
      Scanner.nextLine(); // User Input

      binaryString = binary.toString(); //Casting From Int to String

      while (!binaryString.contains("0") && !binaryString.contains("1")) {
        System.out.println("Enter a valid binary number.");
        //System.out.println("for now binaryString is" + binaryString);
        binary = Scanner.nextInt();
        Scanner.nextLine();
        binaryString = binary.toString(); //Casting From Int to String

      }

      Integer numberLength = binaryString.length(); //Counting how many digits are in the user's number
      String reverseNumber = new StringBuilder(binaryString.toString()).reverse().toString();

      //System.out.println("numberLength = " + numberLength);

      int result = 0;

      for (int i = 0; i < numberLength; i++) { //for numberLenght of times :

        numbers.add((int) binaryString.charAt(i)); //adding data to arraylist, which is the first digit of the number

        Integer numericValue = Character.getNumericValue(reverseNumber.charAt(i));

        double lastNumericValue = numericValue * Math.pow(2, i);

        //System.out.println("I'm calculating " + numericValue + " * 2 at the power of " + i);
        //System.out.println(lastNumericValue); //print the single digit
        System.out.println();
        result = sum += lastNumericValue;

        // System.out.println("numbers.size = " + numbers.size());

      }

      System.out.println(binary + " In decimal numbers is " + result + ".");

      System.out.println("Do you wish to make another conversion?");
      System.out.println("1 = Yes | 2 = No");
      String followingOperation = Scanner.nextLine();

      if (followingOperation.equals("2")) {

        loop = true;
      }

    }

    System.out.println("Press enter to quit the program.");
    String wait = Scanner.nextLine();

  }
}